package com.example.refuelcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddRecieptActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    EditText time;
    TextView did1, date;
    Button addpro,addlit,addbtn;
    DBHelper DB;

    public static String did11 = "";
    public static String date1 = "";
    public static double odometer1 = 0;
    public static double lastodometer1 = 0;
    public static double priceperl1 = 0;
    public static double totalcost1 = 0;
    public static double totalliter1 = 0;
    public static double average1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reciept);
        getSupportActionBar().setTitle("ADD RECIEPT");

        sharedPreferences = getApplication().getSharedPreferences("MyPref", 0);
        editor = sharedPreferences.edit();
        String driverID = sharedPreferences.getString("driverID","");
        did1 = findViewById(R.id.y_did);
        did1.setText(driverID);
        did11 = driverID;

        date = findViewById(R.id.Rdate);
        date.setText(getDateTime());
        date1 = getDateTime();
        time = (EditText) findViewById(R.id.time);
        addpro = (Button) findViewById(R.id.addpro);
        addpro.setOnClickListener(this);
        addlit = (Button) findViewById(R.id.btncalc);
        addlit.setOnClickListener(this);
        addbtn = (Button) findViewById(R.id.addbtn);
        addbtn.setOnClickListener(this);
        DB = new DBHelper(this);


        addlit.setOnClickListener(view -> {
            EditText pricel = (EditText) findViewById(R.id.priceperl);
            TextView totalcost = (TextView) findViewById(R.id.totalcost1);

            double pricell = Double.parseDouble(pricel.getText().toString());
            priceperl1 = pricell;
            double totalcosttt = Double.parseDouble(totalcost.getText().toString());
            totalcost1 = totalcosttt;
            double totallitter = totalcosttt/pricell;
            DecimalFormat formatVal = new DecimalFormat("##.##");
            TextView liters = (TextView) findViewById(R.id.totalliter);
            liters.setText(formatVal.format(totallitter));
            Toast.makeText(getApplicationContext(), "Total Liter Calculated Succesfully and displayed", Toast.LENGTH_LONG).show();
        });

        addpro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText beforeOdo = (EditText) findViewById(R.id.lastodometer);
                TextView fuelInLitres = (TextView) findViewById(R.id.totalliter);
                EditText finalOdo = (EditText) findViewById(R.id.odometer);
                double beforeOdoval = Double.parseDouble(beforeOdo.getText().toString());
                lastodometer1 = beforeOdoval;
                double fuel = Double.parseDouble(fuelInLitres.getText().toString());
                totalliter1 = fuel;
                double afterodo = Double.parseDouble(finalOdo.getText().toString());
                odometer1 = afterodo;
                double mileage = (afterodo-beforeOdoval) / fuel;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                TextView result = (TextView) findViewById(R.id.average);
                result.setText(formatVal.format(mileage));
                average1 = Double.parseDouble(formatVal.format(mileage));
                Toast.makeText(getApplicationContext(), "Mileage Calculated Succesfully and displayed", Toast.LENGTH_LONG).show();
            }});

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(DB.insertdriverenrty(did11, date1, odometer1,lastodometer1,priceperl1,totalcost1,totalliter1,average1)){
                    Toast toast = Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT);
                    toast.show();
                    startActivity(new Intent(AddRecieptActivity.this, BottomActivity.class));
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(), "Data Failed to insert", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }

    public String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    @Override
    public void onClick(View view) {

    }
}