package com.example.refuelcalc;

import static java.security.AccessController.getContext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class BottomActivity extends AppCompatActivity implements View.OnClickListener{
    FloatingActionButton floatingActionButton;
    //Button buttonView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom);
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom1);
        //buttonView=findViewById(R.id.bottom_bar);
        floatingActionButton=findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(this);
        bottomNavigationView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.frame1,new HomeFragment()).commit();

//        floatingActionButton.setOnClickListener(v -> {
//            Intent i=new Intent(getApplicationContext(),AddproActivity.class);
//            startActivity(i);
//        });
//     buttonView.setOnClickListener(new View.OnClickListener(){
//         @Override
//         public void onClick(View view) {
//             Intent i=new Intent(getApplicationContext(),AddproActivity.class);
//             startActivity(i);
//         }
//     });
    }


    private final BottomNavigationView.OnNavigationItemSelectedListener onNavigationItemSelectedListener=new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            Fragment fragment=null;
            switch (menuItem.getItemId())
            {
                case R.id.navigation_home:
                    fragment=new HomeFragment();
                    break;

                case R.id.navigation_chat:
                    fragment=new ChatFragment();
                    break;


                default:
                    throw new IllegalStateException("Unexpected value: " + menuItem.getItemId());
            }
            assert fragment != null;
            getSupportFragmentManager().beginTransaction().replace(R.id.frame1,fragment).commit();
            return true;


        }
    };

    @Override
    public void onClick(View view) {
        startActivity(new Intent(this,AddRecieptActivity.class));
    }
}
