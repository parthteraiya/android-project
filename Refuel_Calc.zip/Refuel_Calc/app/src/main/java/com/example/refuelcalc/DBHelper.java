package com.example.refuelcalc;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.ThemedSpinnerAdapter;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "userTable";
    public static final String id = "id";
    public static final String name = "name";
    public static final String password = "password";
    public static final String phone = "phone";
    public static final String license = "license";
    public static final String driverID = "driverID";


    private static final String date="date";
    private static final String odometer="odometer";
    private static final String totalcost="totalcost";
    private static final String totalliter="totalliter";
    private static final String average="average";


    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public DBHelper(@Nullable Context context) {
        super(context, "FuelManager.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table userTable(name TEXT, password TEXT, phone TEXT, license TEXT, driverID TEXT)");
        String table2 = "CREATE TABLE driverEntry(driverID TEXT,date TEXT,odometer TEXT,lastodometer TEXT, priceperl TEXT, totalcost TEXT, totalliter TEXT, average	TEXT)";
        db.execSQL(table2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists userTable");
        db.execSQL("drop table if exists driverEntry");
    }
    public boolean checkUserName(String driverID1){
        // checking if user name already exists or not
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor =
                sqLiteDatabase.rawQuery("Select * from userTable where driverID = ?", new String[]{driverID1});
        if(cursor.getCount() > 0)
            return true;
        return false;
    }

    public boolean checkUser(String driverID1, String password1) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor =
                sqLiteDatabase.rawQuery("Select * from userTable where driverID = ? and password = ?", new String[]{driverID1, password1});
        if(cursor.getCount() > 0)
            return true;
        return false;
    }
    public Boolean insertuserdata(String name, String password, String phone, String license, String driverID){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("password",password);
        contentValues.put("phone",phone);
        contentValues.put("license",license);
        contentValues.put("driverID",driverID);
        long result = DB.insert("userTable",null,contentValues);

        if(result == -1)
            return false;
        return true;
    }

    public Boolean insertdriverenrty(String did1, String date1, double odometer1, double lastodometer1, double priceperl1, double totalcost1, double totalliter1, double average1){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("driverID",did1);
        contentValues.put("date",date1);
        contentValues.put("odometer",odometer1);
        contentValues.put("lastodometer",lastodometer1);
        contentValues.put("priceperl",priceperl1);
        contentValues.put("totalcost",totalcost1);
        contentValues.put("totalliter",totalliter1);
        contentValues.put("average",average1);
        long result = DB.insert("driverEntry",null,contentValues);
        Log.i("MYTAG","Result "+result);
        Log.i("MYTAG"," "+did1);
        Log.i("MYTAG"," "+date1);
        Log.i("MYTAG"," "+odometer1);
        Log.i("MYTAG"," "+lastodometer1);
        Log.i("MYTAG"," "+priceperl1);
        Log.i("MYTAG"," "+totalcost1);
        Log.i("MYTAG"," "+totalliter1);
        Log.i("MYTAG"," "+average1);
        if(result == -1)
            return false;
        return true;
    }

    @SuppressLint("Range")
    public ArrayList<HashMap<String, String>> GetUsers(String driverID1){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String, String>> userList = new ArrayList<>();
        String query = "SELECT driverID, name, phone, license FROM "+ TABLE_NAME +" WHERE driverID = ?";
        Cursor cursor = db.rawQuery(query,new String[]{driverID1});
        while (cursor.moveToNext()){
            HashMap<String,String> user = new HashMap<>();
            Log.i("MYTAG", " "+driverID);
            user.put("did",cursor.getString(cursor.getColumnIndex(driverID)));
            user.put("name",cursor.getString(cursor.getColumnIndex(name)));
            user.put("phone",cursor.getString(cursor.getColumnIndex(phone)));
            user.put("license",cursor.getString(cursor.getColumnIndex(license)));
            userList.add(user);
        }
        return  userList;
    }

    @SuppressLint("Range")
    public ArrayList<HashMap<String, String>> GetAverage(String driverID1){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String, String>> AverageList = new ArrayList<>();
        String query = "SELECT * FROM driverEntry WHERE driverID = ?";
        Cursor cursor = db.rawQuery(query,new String[]{driverID1});
        while (cursor.moveToNext()){
            HashMap<String,String> user1 = new HashMap<>();
            user1.put("DId2",cursor.getString(cursor.getColumnIndex(driverID)));
            user1.put("date",cursor.getString(cursor.getColumnIndex(date)));
            user1.put("liter",cursor.getString(cursor.getColumnIndex(totalliter)));
            user1.put("average",cursor.getString(cursor.getColumnIndex(average)));
            AverageList.add(user1);
        }
        return  AverageList;
    }

//    public Boolean averagedata(String date, String time, String did1, String codometer, String lodometer,String priceperl,String totalcost,String liter,String average){
//
//        SQLiteDatabase DB=this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("date",date);
//        contentValues.put("time",time);
//        contentValues.put("did1",did1);
//        contentValues.put("codometer",codometer);
//        contentValues.put("lodometer",lodometer);
//        contentValues.put("priceperl",priceperl);
//        contentValues.put("totalcost",totalcost);
//        contentValues.put("liter",liter);
//        contentValues.put("average",average);
//        long result = DB.insert("Average",null,contentValues);
//        return result != -1;
//    }
//    public Cursor getdata()
//    {
//        SQLiteDatabase db=this.getReadableDatabase();
//        return db.rawQuery("Select * from userTable", null);
//    }
}

